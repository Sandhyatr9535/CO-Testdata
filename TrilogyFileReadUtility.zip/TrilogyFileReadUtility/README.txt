Trilogy File Utility
====================

The Trilogy File Utility uploads EDF files to the SDC Gateway, from which annotation and detail data is parsed and
stored in Sapphire.

The utility expects files to be in a configured folder and processes files that have "AD_" and "DD_" substrings in
the file name.



## Running the utility

Type:  java -jar <file-utility.jar> -Dspring.config=<properties-file>

Example:  java -jar TrilogyFileReadUtility-1.0.devBuild.jar -Dspring.config=application.properties

## Configuring the utility

The utility is configured by a properties file that you mention in the CLI startup command.  The properties file
contains three properties:

# trilogyFileLocation specifies the folder containing EDF Files that will be transmitted to the SDC Gateway
trilogyFileLocation=/Users/jimchurch/repo/trilogydatahandlingstaging/TrilogyFileReadUtility/test

# qualComURL specifies the endpoint of the SDC Gateway
qualComURL=http://trilogy-SDCGateway-v1-0-Server.cloud.pcftest.com/api/v1/SDCGateway/trilogyData

# serialNumber specifies the Device Serial Number
serialNumber=TV115051174






