#!/bin/bash

if [ "$#" -ne 3 ]; then
    echo "Usage: <userName> <startDate[yyyy-mm-dd]> <endDate[yyyy-mm-dd]>"
    exit 1
fi

arr=( $(aws s3 ls s3://cf-s3-31b1d82d-20ca-4e61-9885-9b48e06f9023/hipaa-log/user/$1 --recursive --query "Contents[?LastModified >= '$2' && LastModified <= '$3'].Key" | grep .json | cut -c 32-))
for i in "${arr[@]}"
do
   #echo "$i"
   aws s3 cp s3://cf-s3-31b1d82d-20ca-4e61-9885-9b48e06f9023/${i} ${i}
   aws s3 cp s3://cf-s3-31b1d82d-20ca-4e61-9885-9b48e06f9023/$(cat ${i} | awk -F'":"' '{print $2}' | sed 's/"}/''/') ${i}
   cat ${i} >> Hipaa.json
   echo \n >> Hipaa.json
done

